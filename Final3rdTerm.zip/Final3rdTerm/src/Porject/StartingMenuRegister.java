package Porject;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JSpinner;
import javax.swing.JLabel;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.border.LineBorder;

public class StartingMenuRegister extends JFrame {
	
	//Salivio, Carl Warren - Lu, John Resty Geraldo part
	
	//imported image/can be replace
	private Image logoicon = new ImageIcon(StartingMenuLogIN.class.getResource("/imageres/logo.png")).getImage().getScaledInstance(315, 235, Image.SCALE_SMOOTH);


	private JPanel contentPane;
	private JTextField exitButton;
	private JTextField firstnametxt;
	private JTextField middlenametxt;
	private JTextField lastnametxt;
	private JTextField bmonthtxt;
	private JTextField byeartxt;
	private JTextField addresstxt;
	private JTextField gendertxt;
	private JTextField contacttxt;
	private JTextField fathernametxt;
	private JTextField mothernametxt;
	private JTextField initialdeposittxt;
	private JLabel title;
	private JPanel registerbuttonbody;
	private JLabel registerbutton;
	private JLabel toLogIn;
	private JLabel logo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartingMenuRegister frame = new StartingMenuRegister();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StartingMenuRegister() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 51, 51));
		contentPane.setBorder(new LineBorder(new Color(178, 34, 34)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//exit button/code
		exitButton = new JTextField();
		exitButton.setEditable(false);
		exitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(JOptionPane.showConfirmDialog(null,"Are You sure you want to exit the program?","Confirmation" ,JOptionPane.YES_NO_OPTION) == 0) {
					System.exit(0);
				}
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				exitButton.setForeground(Color.red);
			}
			@Override
			public void mouseExited(MouseEvent e) {
				exitButton.setForeground(Color.WHITE);
			}
		});
		exitButton.setBackground(new Color(204, 51, 51));
		exitButton.setForeground(Color.WHITE);
		exitButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		exitButton.setHorizontalAlignment(SwingConstants.CENTER);
		exitButton.setText("X");
		exitButton.setBounds(858, 10, 32, 19);
		contentPane.add(exitButton);
		exitButton.setColumns(10);
		exitButton.setBorder(null);
		
		//paneldesign/code
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(153, 51, 0)));
		panel.setBackground(new Color(153, 51, 51));
		panel.setBounds(0, 0, 394, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		//firstname textfield/code
		firstnametxt = new JTextField();
		firstnametxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter First Name" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(firstnametxt.getText().equals("Enter First Name")) {
					firstnametxt.setForeground(Color.black);
					firstnametxt.setText("");
				}
				else {
					firstnametxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter First Name" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(firstnametxt.getText().equals("")) {
					firstnametxt.setForeground(Color.GRAY);
					firstnametxt.setText("Enter First Name");
				}
			}
		});
		firstnametxt.setBounds(40, 386, 315, 40);
		panel.add(firstnametxt);
		firstnametxt.setForeground(Color.GRAY);
		firstnametxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		firstnametxt.setText("Enter First Name");
		firstnametxt.setColumns(10);
		
		//middle name text field/code
		middlenametxt = new JTextField();
		middlenametxt.setForeground(Color.GRAY);
		middlenametxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Middle Name" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(middlenametxt.getText().equals("Enter Middle Name")) {
					middlenametxt.setForeground(Color.black);
					middlenametxt.setText("");
				}
				else {
					middlenametxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Middle Name" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(middlenametxt.getText().equals("")) {
					middlenametxt.setForeground(Color.GRAY);
					middlenametxt.setText("Enter Middle Name");
				}
			}
		});
		middlenametxt.setBounds(40, 436, 315, 40);
		panel.add(middlenametxt);
		middlenametxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		middlenametxt.setText("Enter Middle Name");
		middlenametxt.setColumns(10);
		
		//lastname textfield/code
		lastnametxt = new JTextField();
		lastnametxt.setForeground(Color.GRAY);
		lastnametxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Last Name" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(lastnametxt.getText().equals("Enter Last Name")) {
					lastnametxt.setForeground(Color.black);
					lastnametxt.setText("");
				}
				else {
					lastnametxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Last Name" will be Back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(lastnametxt.getText().equals("")) {
					lastnametxt.setForeground(Color.GRAY);
					lastnametxt.setText("Enter Last Name");
				}
			}
		});
		lastnametxt.setBounds(40, 486, 315, 40);
		panel.add(lastnametxt);
		lastnametxt.setText("Enter Last Name");
		lastnametxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lastnametxt.setColumns(10);
		
		//titlelabel code
		title = new JLabel("Register");
		title.setForeground(new Color(255, 255, 255));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setFont(new Font("Tahoma", Font.BOLD, 34));
		title.setBounds(40, 295, 315, 81);
		panel.add(title);
		
		//logo image/code
		logo = new JLabel("");
		logo.setBounds(40, 47, 315, 235);
		logo.setIcon(new ImageIcon(logoicon));
		panel.add(logo);
		
		//day of birthday textfield/code
		JTextField bdaytxt = new JTextField();
		bdaytxt.setForeground(Color.GRAY);
		bdaytxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "dd" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(bdaytxt.getText().equals("dd")) {
					bdaytxt.setForeground(Color.black);
					bdaytxt.setText("");
				}
				else {
					bdaytxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "dd" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(bdaytxt.getText().equals("")) {
					bdaytxt.setForeground(Color.GRAY);
					bdaytxt.setText("dd");
				}
			}
		});
		bdaytxt.setHorizontalAlignment(SwingConstants.CENTER);
		bdaytxt.setBounds(479, 54, 40, 40);
		contentPane.add(bdaytxt);
		bdaytxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		bdaytxt.setText("dd");
		bdaytxt.setColumns(10);
		
		//birth month textfield/code
		bmonthtxt = new JTextField();
		bmonthtxt.setForeground(Color.GRAY);
		bmonthtxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "mm" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(bmonthtxt.getText().equals("mm")) {
					bmonthtxt.setForeground(Color.black);
					bmonthtxt.setText("");
				}
				else {
					bmonthtxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "mm" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(bmonthtxt.getText().equals("")) {
					bmonthtxt.setForeground(Color.GRAY);
					bmonthtxt.setText("mm");
				}
			}
		});
		bmonthtxt.setHorizontalAlignment(SwingConstants.CENTER);
		bmonthtxt.setBounds(529, 54, 40, 40);
		contentPane.add(bmonthtxt);
		bmonthtxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		bmonthtxt.setText("mm");
		bmonthtxt.setColumns(10);
		
		//birth year textfield/code
		byeartxt = new JTextField();
		byeartxt.setForeground(Color.GRAY);
		byeartxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "yyyy" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(byeartxt.getText().equals("yyyy")) {
					byeartxt.setForeground(Color.black);
					byeartxt.setText("");
				}
				else {
					byeartxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "yyyy" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(byeartxt.getText().equals("")) {
					byeartxt.setForeground(Color.GRAY);
					byeartxt.setText("yyyy");
				}
			}
		});
		byeartxt.setHorizontalAlignment(SwingConstants.CENTER);
		byeartxt.setBounds(580, 54, 113, 40);
		contentPane.add(byeartxt);
		byeartxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		byeartxt.setText("yyyy");
		byeartxt.setColumns(10);
		
		//gender textfield/code
		gendertxt = new JTextField();
		gendertxt.setForeground(Color.GRAY);
		gendertxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Gender" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(gendertxt.getText().equals("Gender")) {
					gendertxt.setForeground(Color.black);
					gendertxt.setText("");
				}
				else {
					gendertxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Gender" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(gendertxt.getText().equals("")) {
					gendertxt.setForeground(Color.GRAY);
					gendertxt.setText("Gender");
				}
			}
		});
		gendertxt.setBounds(702, 54, 92, 40);
		contentPane.add(gendertxt);
		gendertxt.setText("Gender");
		gendertxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		gendertxt.setColumns(10);
		
		//address textfield/code
		addresstxt = new JTextField();
		addresstxt.setForeground(Color.GRAY);
		addresstxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Address" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(addresstxt.getText().equals("Enter Address")) {
					addresstxt.setForeground(Color.black);
					addresstxt.setText("");
				}
				else {
					addresstxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Address" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(addresstxt.getText().equals("")) {
					addresstxt.setForeground(Color.GRAY);
					addresstxt.setText("Enter Address");
				}
			}
		});
		addresstxt.setBounds(479, 104, 315, 135);
		contentPane.add(addresstxt);
		addresstxt.setHorizontalAlignment(SwingConstants.LEFT);
		addresstxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		addresstxt.setText("Enter Address");
		addresstxt.setColumns(10);
		
		//contact textfield/code
		contacttxt = new JTextField();
		contacttxt.setForeground(Color.GRAY);
		contacttxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Contact No." will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(contacttxt.getText().equals("Enter Contact No.")) {
					contacttxt.setForeground(Color.black);
					contacttxt.setText("");
				}
				else {
					contacttxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Contact No." will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(contacttxt.getText().equals("")) {
					contacttxt.setForeground(Color.GRAY);
					contacttxt.setText("Enter Contact No.");
				}
			}
		});
		contacttxt.setText("Enter Contact No.");
		contacttxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		contacttxt.setColumns(10);
		contacttxt.setBounds(479, 249, 315, 40);
		contentPane.add(contacttxt);
		
		//father's name textfield/code
		fathernametxt = new JTextField();
		fathernametxt.setForeground(Color.GRAY);
		fathernametxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Father's Name" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(fathernametxt.getText().equals("Enter Father's Name")) {
					fathernametxt.setForeground(Color.black);
					fathernametxt.setText("");
				}
				else {
					fathernametxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Father's Name" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(fathernametxt.getText().equals("")) {
					fathernametxt.setForeground(Color.GRAY);
					fathernametxt.setText("Enter Father's Name");
				}
			}
		});
		fathernametxt.setText("Enter Father's Name");
		fathernametxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		fathernametxt.setColumns(10);
		fathernametxt.setBounds(479, 299, 315, 40);
		contentPane.add(fathernametxt);
		
		//mother's name textfield/code
		mothernametxt = new JTextField();
		mothernametxt.setForeground(Color.GRAY);
		mothernametxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Mother's Name" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(mothernametxt.getText().equals("Enter Mother's Name")) {
					mothernametxt.setForeground(Color.black);
					mothernametxt.setText("");
				}
				else {
					fathernametxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Mother's Name" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(mothernametxt.getText().equals("")) {
					mothernametxt.setForeground(Color.GRAY);
					mothernametxt.setText("Enter Mother's Name");
				}
			}
		});
		mothernametxt.setText("Enter Mother's Name");
		mothernametxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		mothernametxt.setColumns(10);
		mothernametxt.setBounds(479, 349, 315, 40);
		contentPane.add(mothernametxt);
		
		//initisl deposit textfield/code
		initialdeposittxt = new JTextField();
		initialdeposittxt.setForeground(Color.GRAY);
		initialdeposittxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Initial Deposit" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(initialdeposittxt.getText().equals("Enter Initial Deposit")) {
					initialdeposittxt.setForeground(Color.black);
					initialdeposittxt.setText("");
				}
				else {
					initialdeposittxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Initial Deposit" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(initialdeposittxt.getText().equals("")) {
					initialdeposittxt.setForeground(Color.GRAY);
					initialdeposittxt.setText("Enter Initial Deposit");
				}
			}
		});
		initialdeposittxt.setText("Enter Initial Deposit");
		initialdeposittxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		initialdeposittxt.setColumns(10);
		initialdeposittxt.setBounds(479, 399, 315, 40);
		contentPane.add(initialdeposittxt);
		
		//to register account button's body/code
		registerbuttonbody = new JPanel();
		registerbuttonbody.setBorder(new LineBorder(new Color(153, 51, 0)));
		registerbuttonbody.addMouseListener(new MouseAdapter() {
			//whenever the user entered the mouse cursor in the label the background color changes
			@Override
			public void mouseEntered(MouseEvent e) {
				registerbuttonbody.setBackground(new Color(133, 21, 31));
			}
			//whenever the user exited the mouse cursor in the label the background color changes
			@Override
			public void mouseExited(MouseEvent e) {
				registerbuttonbody.setBackground(new Color(153, 51, 51));
			}
		});
		registerbuttonbody.setBackground(new Color(153, 51, 51));
		registerbuttonbody.setBounds(532, 467, 222, 60);
		contentPane.add(registerbuttonbody);
		registerbuttonbody.setLayout(null);
		
		registerbutton = new JLabel("REGISTER");
		registerbutton.addMouseListener(new MouseAdapter() {
			//whenever the user entered the mouse cursor in the label the foreground color changes
			@Override
			public void mouseEntered(MouseEvent e) {
				registerbutton.setForeground(Color.gray);
			}
			//whenever the user exited the mouse cursor in the label the foreground color changes
			@Override
			public void mouseExited(MouseEvent e) {
				registerbutton.setForeground(Color.WHITE);
			}
		});
		registerbutton.setHorizontalAlignment(SwingConstants.CENTER);
		registerbutton.setForeground(Color.WHITE);
		registerbutton.setFont(new Font("Tahoma", Font.BOLD, 18));
		registerbutton.setBounds(54, 10, 100, 40);
		registerbuttonbody.add(registerbutton);
		
		//to return to Login page/code
		toLogIn = new JLabel("Already have an account? Click here to Log-in");
		toLogIn.addMouseListener(new MouseAdapter() {
			//whenever the user entered the mouse cursor in the label the foreground color changes
			@Override
			public void mouseEntered(MouseEvent e) {
				toLogIn.setForeground(Color.gray);
			}
			//whenever the user exited the mouse cursor in the label the foreground color changes
			@Override
			public void mouseExited(MouseEvent e) {
				toLogIn.setForeground(Color.WHITE);
			}
			//click the label to return to log in page/code
			@Override
			public void mouseClicked(MouseEvent e) {
				StartingMenuLogIN logIn = new StartingMenuLogIN();
				logIn.setVisible(true);
				dispose();
			}
		});
		toLogIn.setForeground(Color.WHITE);
		toLogIn.setHorizontalAlignment(SwingConstants.CENTER);
		toLogIn.setFont(new Font("Tahoma", Font.BOLD, 10));
		toLogIn.setBounds(503, 537, 291, 13);
		contentPane.add(toLogIn);
		setUndecorated(true);
		
		
	}
}
