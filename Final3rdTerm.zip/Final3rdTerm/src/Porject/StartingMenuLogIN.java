package Porject;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;

public class StartingMenuLogIN extends JFrame {
	
	//Salivio, Carl Warren - Lu, John Resty Geraldo part
	
	//imported image/can be replace
	private Image close = new ImageIcon(StartingMenuLogIN.class.getResource("/imageres/Close.png")).getImage().getScaledInstance(38, 38, Image.SCALE_SMOOTH);
	private Image open = new ImageIcon(StartingMenuLogIN.class.getResource("/imageres/Open.png")).getImage().getScaledInstance(38, 38, Image.SCALE_SMOOTH);
	private Image usericon = new ImageIcon(StartingMenuLogIN.class.getResource("/imageres/user.png")).getImage().getScaledInstance(38, 38, Image.SCALE_SMOOTH);
	private Image logo = new ImageIcon(StartingMenuLogIN.class.getResource("/imageres/logo.png")).getImage().getScaledInstance(180, 140, Image.SCALE_SMOOTH);

	private JPanel logInPage;
	private JTextField exitButton;
	private JTextField toRegister;
	private JTextField usernametxt;
	private JPasswordField passwordField;
	private JPanel panel;
	private JLabel viewpass;
	private JLabel hidepass;
	private JLabel usericonlbl;
	private JLabel logosample;
	private JLabel titlelogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartingMenuLogIN frame = new StartingMenuLogIN();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StartingMenuLogIN() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 450);
		setLocationRelativeTo(null);
		logInPage = new JPanel();
		logInPage.setBackground(new Color(204, 51, 51));
		logInPage.setBorder(new LineBorder(new Color(178, 34, 34)));
		setContentPane(logInPage);
		setUndecorated(true);
		logInPage.setLayout(null);
		
		//Exit Button part code
		exitButton = new JTextField();
		exitButton.setHorizontalAlignment(SwingConstants.CENTER);
		exitButton.setToolTipText("");
		exitButton.setEditable(false);
		exitButton.setBorder(null);
		exitButton.addMouseListener(new MouseAdapter() {
			//Confirmation if you want to exit or not/code
			@Override
			public void mouseClicked(MouseEvent e) {
				if(JOptionPane.showConfirmDialog(null,"Are You sure you want to exit the program?","Confirmation" ,JOptionPane.YES_NO_OPTION) == 0) {
					System.exit(0);
				}
			}
			//whenever the user entered the mouse cursor in the label the foreground color changes
			@Override
			public void mouseEntered(MouseEvent e) {
				exitButton.setForeground(Color.RED);
			}
			//whenever the user exited the mouse cursor in the label the foreground color changes
			@Override
			public void mouseExited(MouseEvent e) {
				exitButton.setForeground(Color.WHITE);
			}
		});
		exitButton.setBackground(new Color(204, 51, 51));
		exitButton.setFont(new Font("Tahoma", Font.BOLD, 24));
		exitButton.setForeground(Color.WHITE);
		exitButton.setText("X");
		exitButton.setBounds(660, 10, 30, 22);
		logInPage.add(exitButton);
		exitButton.setColumns(10);
		
		//button to go to register page/code
		toRegister = new JTextField();
		toRegister.setEditable(false);
		toRegister.setBorder(null);
		toRegister.addMouseListener(new MouseAdapter() {
			@Override
			//if the label is clicked the user will proceed to the other menu which is register
			public void mouseClicked(MouseEvent e) {
				StartingMenuRegister register = new StartingMenuRegister();
				register.setVisible(true);
				dispose();
			}
			//whenever the user entered the mouse cursor in the label the foreground color changes
			@Override
			public void mouseEntered(MouseEvent e) {
				toRegister.setForeground(Color.gray);
			}
			//whenever the user exited the mouse cursor in the label the foreground color changes
			@Override
			public void mouseExited(MouseEvent e) {
				toRegister.setForeground(Color.WHITE);
			}
		});
		toRegister.setForeground(Color.WHITE);
		toRegister.setFont(new Font("Tahoma", Font.BOLD, 10));
		toRegister.setHorizontalAlignment(SwingConstants.CENTER);
		toRegister.setText("Doesn't have an account yet? Click here to Register");
		toRegister.setBackground(new Color(204, 51, 51));
		toRegister.setBounds(288, 333, 345, 19);
		logInPage.add(toRegister);
		toRegister.setColumns(10);
		
		//username input/code
		usernametxt = new JTextField();
		usernametxt.setForeground(Color.GRAY);
		usernametxt.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the textfield the label "Enter Username" will be remove in the field
			@Override
			public void focusGained(FocusEvent e) {
				if(usernametxt.getText().equals("Enter Username")) {
					usernametxt.setForeground(Color.black);
					usernametxt.setText("");
				}
				else {
					usernametxt.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the textfield the label "Enter Username" will be back in the field
			@Override
			public void focusLost(FocusEvent e) {
				if(usernametxt.getText().equals("")) {
					usernametxt.setForeground(Color.GRAY);
					usernametxt.setText("Enter Username");
				}
			}
		});
		usernametxt.setFont(new Font("Tahoma", Font.PLAIN, 18));
		usernametxt.setText("Enter Username");
		usernametxt.setBounds(326, 161, 307, 38);
		logInPage.add(usernametxt);
		usernametxt.setColumns(10);
		
		//password input/code
		passwordField = new JPasswordField();
		passwordField.setForeground(Color.GRAY);
		passwordField.addFocusListener(new FocusAdapter() {
			//whenever the user focuses/click the mouse cursor in the passwordfield the label "Enter Password" will be remove in the field and the echochar will be back to dot
			@Override
			public void focusGained(FocusEvent e) {
				if(passwordField.getText().equals("Enter Password")) {
					passwordField.setForeground(Color.black);
					passwordField.setEchoChar('●');
					passwordField.setText("");
				}
				else {
					passwordField.selectAll();
				}
			}
			//whenever the user unfocus the mouse cursor in the passwordfield the label "Enter Password" will be back in the field and the echochar will be letters
			@Override
			public void focusLost(FocusEvent e) {
				if(passwordField.getText().equals("")) {
					passwordField.setForeground(Color.GRAY);
					passwordField.setText("Enter Password");
					passwordField.setEchoChar((char)0);
					
				}
			}
		});
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		passwordField.setBounds(326, 209, 307, 38);
		passwordField.setEchoChar((char)0);
		passwordField.setText("Enter Password");
		logInPage.add(passwordField);
		
		//log - in body button/code
		JPanel loginbutton = new JPanel();
		loginbutton.addMouseListener(new MouseAdapter() {
			//whenever the user entered the mouse cursor in the label the background color changes
			@Override
			public void mouseEntered(MouseEvent e) {
				loginbutton.setBackground(new Color(130, 31, 0));
			}
			//whenever the user exited the mouse cursor in the label the background color changes
			@Override
			public void mouseExited(MouseEvent e) {
				loginbutton.setBackground(new Color(153, 51, 0));
			}
		});
		loginbutton.setBorder(new LineBorder(new Color(153, 51, 0)));
		loginbutton.setBackground(new Color(153, 51, 0));
		loginbutton.setForeground(Color.LIGHT_GRAY);
		loginbutton.setBounds(378, 274, 166, 38);
		logInPage.add(loginbutton);
		loginbutton.setLayout(null);
		
		//log - in button text/code/
		JLabel loginlabelbutton = new JLabel("LOG - IN");
		loginlabelbutton.addMouseListener(new MouseAdapter() {
			//whenever the user entered the mouse cursor in the label the foreground color changes
			@Override
			public void mouseEntered(MouseEvent e) {
				loginlabelbutton.setForeground(Color.gray);
			}
			//whenever the user exited the mouse cursor in the label the foreground color changes
			@Override
			public void mouseExited(MouseEvent e) {
				loginlabelbutton.setForeground(Color.WHITE);
			}
		});
		loginlabelbutton.setForeground(Color.WHITE);
		loginlabelbutton.setFont(new Font("Tahoma", Font.BOLD, 14));
		loginlabelbutton.setHorizontalAlignment(SwingConstants.CENTER);
		loginlabelbutton.setBounds(10, 10, 146, 18);
		loginbutton.add(loginlabelbutton);
		
		//design panel/code
		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(153, 51, 0)));
		panel.setBackground(new Color(153, 51, 0));
		panel.setBounds(0, 0, 233, 450);
		logInPage.add(panel);
		panel.setLayout(null);
		
		//logo panel/code
		logosample = new JLabel("");
		logosample.setBounds(27, 100, 180, 140);
		logosample.setIcon(new ImageIcon(logo));
		panel.add(logosample);
		
		//title/code
		titlelogin = new JLabel("Log - In");
		titlelogin.setForeground(Color.WHITE);
		titlelogin.setHorizontalAlignment(SwingConstants.CENTER);
		titlelogin.setFont(new Font("Tahoma", Font.BOLD, 22));
		titlelogin.setBounds(27, 250, 180, 39);
		panel.add(titlelogin);
		
		//to view the characters in passwordfield/code
		viewpass = new JLabel("");
		viewpass.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewpass.setVisible(false);
				hidepass.setVisible(true);
				passwordField.setEchoChar((char)0);
			}
		});
		viewpass.setIcon(new ImageIcon(close));
		viewpass.setBorder(null);
		viewpass.setBounds(288, 209, 37, 37);
		logInPage.add(viewpass);
		
		//to hide the characters in passwordfield/code
		hidepass = new JLabel("");
		hidepass.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				viewpass.setVisible(true);
				hidepass.setVisible(false);
				passwordField.setEchoChar('●');
			}
		});
		hidepass.setVisible(false);
		hidepass.setBounds(288, 209, 37, 37);
		hidepass.setIcon(new ImageIcon(open));
		logInPage.add(hidepass);
		
		//usericon/code
		usericonlbl = new JLabel("");
		usericonlbl.setBounds(288, 162, 37, 37);
		usericonlbl.setIcon(new ImageIcon(usericon));
		logInPage.add(usericonlbl);
	}
}
